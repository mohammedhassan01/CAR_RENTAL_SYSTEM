
public class FourXFourRental implements RentalBillingStrategy {
	
	private Rental rental ;
	
	public  FourXFourRental(Rental rental) {
		this.rental = rental ;
	}

	@Override
	public double getRentalAmount(Rental rental) {
		int amount = rental.getRentalRules().AMOUNT_PER_DAY * rental.getRentalData().getDaysRented();
		if(rental.getRentalData().isLateFee())
		{
			amount += amount * rental.getRentalRules().RENTAL_LATE_FACTOR ;
		}
		return amount ;
	}

	@Override
	public int getRentalReward(Rental rental, int preRewardPoints) {
		int rewardPoints = preRewardPoints ;
		if(!rental.getRentalData().isLateFee())
		{
			rewardPoints++;
			rewardPoints *= rewardPoints * rental.getRentalRules().REWARD_POINTS_FACTOR ;
		}
		return rewardPoints;
	}

	@Override
	public String getRentalAmountStatment(Rental rental) {
		// TODO Auto-generated method stub
		return null;
	}
}
