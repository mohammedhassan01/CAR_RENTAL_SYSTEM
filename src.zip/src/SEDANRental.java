
public class SEDANRental implements RentalBillingStrategy {

	private Rental rental;

	public SEDANRental(Rental rental) {
		this.rental = rental;
	}

	private int getRentalExceededMiles() {
		return rental.getRentalData().getKilometersRented() - 
				(rental.getRentalData().getDaysRented() * rental.getRentalRules().MILES_LIMIT_PER_DAY);
	}

	@Override
	public double getRentalAmount(Rental rental) {
		int amount = rental.getRentalRules().AMOUNT_PER_DAY * rental.getRentalData().getDaysRented();
		if (getRentalExceededMiles() > 0) {
			amount += getRentalExceededMiles() * rental.getRentalRules().FACTOR_AFTER_MILE_EXCEED;
		}
		if (rental.getRentalData().isLateFee()) {
			amount += amount * rental.getRentalRules().RENTAL_LATE_FACTOR;
		}
		return amount;
	}

	@Override
	public int getRentalReward(Rental rental, int preRewardPoints) {
		int rewardPoints = 0;
		if (!rental.getRentalData().isLateFee()) {
			rewardPoints++;
		}
		return rewardPoints;
	}

	@Override
	public String getRentalAmountStatment(Rental rental) {
		// TODO Auto-generated method stub
		return null;
	}

}
