
public interface Formatter<T> {
	public String getValue(T object);
}
