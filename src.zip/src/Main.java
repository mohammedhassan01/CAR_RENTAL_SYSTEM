
public class Main {

	public static void main(String[] args) {

		Vehicle blueHonda = new Vehicle("Blue Honda 2008", VehicleType.SEDAN);
		Vehicle greyJeep = new Vehicle("Grey Jeep 2013", VehicleType.FOURxFOUR);
		Vehicle RedSunny = new Vehicle("Red Sunny 2014", VehicleType.SEDAN);
		Vehicle BlueBMW = new Vehicle("Blue X3 2017", VehicleType.SUV);

		RentalData rentalData1 = new RentalData(431, 4, false);
		RentalData rentalData2 = new RentalData(744, 4, false);
		RentalData rentalData3 = new RentalData(591, 3, true);
		RentalData rentalData4 = new RentalData(240, 5, false);
		
		
		RentalRules rentalRules1 = new RentalRules(100, 50, 2, 1, 1,  );

		Customer virginGates = new Customer("Virgin Gates");
		Customer sharmDreams = new Customer("Sharm Dreams");

		virginGates.addRental(hondaRental);
		virginGates.addRental(jeepRental);
		virginGates.addRental(sunnnyRental);

		sharmDreams.addRental(x3Rental);

		virginGates.statementTest();
		sharmDreams.statementTest();

	}

}
