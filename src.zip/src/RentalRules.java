
public class RentalRules {
	public final int AMOUNT_PER_DAY;
	public final int MILES_LIMIT_PER_DAY ;
	public final int FACTOR_AFTER_MILE_EXCEED ;
	public final double RENTAL_LATE_FACTOR ;
	public final int REWARD_POINTS_FACTOR;
	public final int REWARD_POINTS_THRESHOLD;
	
	public RentalRules(int amountPerDay, int milesLimitPerDay, int factorAfaterMileExceed, double rentalRateFactor, int rewardPointFactor,
			int rewardPointsThreshold)
	{
		this.AMOUNT_PER_DAY = amountPerDay ;
		this.MILES_LIMIT_PER_DAY = milesLimitPerDay;
		this.FACTOR_AFTER_MILE_EXCEED = factorAfaterMileExceed;
		this.RENTAL_LATE_FACTOR = rentalRateFactor;
		this.REWARD_POINTS_FACTOR = rewardPointFactor;
		this.REWARD_POINTS_THRESHOLD = rewardPointsThreshold;
	}

}
