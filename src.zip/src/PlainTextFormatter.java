
public interface PlainTextFormatter{

	public String getPlainTextValue(Object object);

}
