
public class BillingPlanType {
	public static final int SEDAN_PILLING = 1 ; 
	public static final int SUV_PILLING = 2  ;
	public static final int FOUR_X_FOUR_PILLING = 3 ;
}
